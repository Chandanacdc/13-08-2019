package com.example.courier1.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.courier1.Couriers.dao.CouriersDao;
import com.example.courier1.bean.Couriers;

@Service
public class CourierServiceImpl implements CourierService {

	@Autowired
	private CouriersDao dao;

	@Override
	public List<Couriers> getAllCourier() {
		List<Couriers> courier=new ArrayList<Couriers>();
		Iterator<Couriers> iterator = dao.findAll().iterator();
		while(iterator.hasNext()) {
			courier.add(iterator.next());
		}
		return courier;
	}

	@Override
	public Couriers createCourier(Couriers courier) {
		return dao.save(courier);
	}

	@Override
	public Couriers delete(Integer custId) {
		try {
			System.out.println("before");
			Couriers courier = dao.getOne(custId);
	        if(courier != null){
	        	System.out.println("inside if");
	            dao.delete(courier);
	            System.out.println("after delete");
	        }
	        return courier;
		}catch(Exception e) {
			System.out.println("Inside catch");
			e.printStackTrace();
			return null;
		}
	}


	
	
}
