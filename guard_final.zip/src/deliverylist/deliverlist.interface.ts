export interface DeliverList{
    
    courierId:number;
    name:string;
    
    email:string;
  
    contact:string;
}